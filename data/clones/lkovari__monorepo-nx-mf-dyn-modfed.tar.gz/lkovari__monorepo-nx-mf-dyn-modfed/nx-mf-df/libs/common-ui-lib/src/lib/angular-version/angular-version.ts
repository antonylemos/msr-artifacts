import { NgStyle } from '@angular/common';
import { ChangeDetectionStrategy, Component, input, signal } from '@angular/core';
import { VERSION } from '@angular/core';

@Component({
  selector: 'lib-angular-version',
  imports: [NgStyle],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './angular-version.html',
  styleUrl: './angular-version.css',
})
export class AngularVersion {
  protected readonly angularVersion = signal(VERSION.full);
  textStyle = input<{ [key: string]: string }>({});
}
