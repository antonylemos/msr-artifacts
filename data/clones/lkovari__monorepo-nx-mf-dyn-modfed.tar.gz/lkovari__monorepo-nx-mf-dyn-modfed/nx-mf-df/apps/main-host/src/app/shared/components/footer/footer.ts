import { ChangeDetectionStrategy, Component } from '@angular/core';
import { AngularVersion, NxVersion } from '@nx-mf-df/common-ui-lib';

@Component({
  selector: 'nxmfdf-footer',
  imports: [NxVersion, AngularVersion],
  templateUrl: './footer.html',
  styleUrl: './footer.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class Footer {
  protected readonly copyrightYear = 2026;
  protected readonly versionTextStyle = { color: 'magenta' };  
}
