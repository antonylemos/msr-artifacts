declare module 'single-spa';
