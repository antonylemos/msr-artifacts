import mockAxios from 'axios';
import log from 'loglevel';
import { Action, AnyAction } from 'redux';
import JWTAuthProvider from '../../authentication/jwtAuthProvider';
import TestAuthProvider from '../../authentication/testAuthProvider';
import { flushPromises } from '../../testUtils';
import { initialState } from '../reducers/scigateway.reducer';
import {
  AddHelpTourStepsType,
  ConfigureAnalyticsType,
  ConfigureFeatureSwitchesType,
  DismissNotificationType,
  InitialiseAnalyticsType,
  NotificationType,
  ResetAuthStateType,
  ToggleDrawerType,
  ToggleHelpType,
} from '../scigateway.types';
import { StateType } from '../state.types';
import loadMicroFrontends from './loadMicroFrontends';
import {
  addHelpTourSteps,
  authorised,
  configureAnalytics,
  configureSite,
  customAdminPageDefaultTab,
  customLogo,
  customNavigationDrawerLogo,
  customPrimaryColour,
  dismissMenuItem,
  initialiseAnalytics,
  invalidToken,
  loadDarkModePreference,
  loadedAuthentication,
  loadFeatureSwitches,
  loadHighContrastModePreference,
  loadingAuthentication,
  loadMaintenanceState,
  loadScheduledMaintenanceState,
  loadStrings,
  registerContactUsAccessibilityFormUrl,
  registerHomepageUrl,
  resetAuthState,
  siteLoadingUpdate,
  toggleDrawer,
  toggleHelp,
  verifyUsernameAndPassword,
} from './scigateway.actions';

function mockAxiosGetResponse(message: string): void {
  vi.mocked(mockAxios.get).mockImplementationOnce(() =>
    Promise.resolve({
      data: {
        title: message,
      },
    })
  );
}

describe('scigateway actions', () => {
  beforeEach(() => {
    vi.useFakeTimers();

    vi.mocked(mockAxios.get).mockReset();

    vi.mocked(mockAxios.post).mockImplementationOnce(() =>
      Promise.resolve({
        data: {
          token: 'token123',
        },
      })
    );

    loadMicroFrontends.init = vi
      .fn()
      .mockImplementation(() => Promise.resolve());
  });

  afterEach(() => {
    vi.runOnlyPendingTimers();
    vi.useRealTimers();
  });

  it('toggleDrawer only needs a type', () => {
    const action = toggleDrawer();
    expect(action.type).toEqual(ToggleDrawerType);
  });

  it('given valid credentials verifyUsernameAndPassword should return with a valid token and successful authorisation', async () => {
    mockAxiosGetResponse(
      'this will be replaced by an API call to get access token'
    );

    const authUrl = 'http://example.com';

    const asyncAction = verifyUsernameAndPassword('username', 'password');
    const actions: Action[] = [];
    const dispatch = (action: Action): number => actions.push(action);
    const state = JSON.parse(JSON.stringify(initialState));
    state.authorisation.provider = new TestAuthProvider(null);
    state.authorisation.provider.authUrl = authUrl;
    state.authorisation.provider.autoLogin = () => Promise.resolve();

    const getState = (): Partial<StateType> => ({
      scigateway: state,
    });

    const action = asyncAction(dispatch, getState);
    vi.runAllTimers();
    await action;

    expect(actions[0]).toEqual(loadingAuthentication());
    expect(actions[1]).toEqual(authorised());
  });

  it('given invalid credentials verifyUsernameAndPassword should return an authorisation failure', async () => {
    mockAxiosGetResponse(
      'this will be replaced by an API call to get access token'
    );

    const asyncAction = verifyUsernameAndPassword('INVALID_NAME', 'password');
    const actions: Action[] = [];
    const dispatch = (action: Action): number => actions.push(action);

    const state = JSON.parse(JSON.stringify(initialState));
    state.authorisation.provider = new TestAuthProvider(null);
    const getState = (): Partial<StateType> => ({ scigateway: state });

    const action = asyncAction(dispatch, getState);
    vi.runAllTimers();
    await action;

    const expectedResponse = {
      type: 'scigateway:auth_failure',
      payload: { errorCode: undefined },
    };

    expect(actions[0]).toEqual(loadingAuthentication());
    expect(actions[1]).toEqual(expectedResponse);
  });

  it('given axios error response verifyUsernameAndPassword should return an authorisation failure with error code', async () => {
    vi.mocked(mockAxios.post).mockReset();
    vi.mocked(mockAxios.post).mockImplementation(() => {
      return Promise.reject({
        response: {
          status: 500,
        },
      });
    });

    const asyncAction = verifyUsernameAndPassword('username', 'password');
    const actions: Action[] = [];
    const dispatch = (action: Action): number => actions.push(action);

    const state = JSON.parse(JSON.stringify(initialState));
    state.authorisation.provider = new JWTAuthProvider(undefined);
    const getState = (): Partial<StateType> => ({ scigateway: state });

    const action = asyncAction(dispatch, getState);
    vi.runAllTimers();
    await action;

    const expectedResponse = {
      type: 'scigateway:auth_failure',
      payload: { errorCode: 500 },
    };

    expect(actions[0]).toEqual(loadingAuthentication());
    expect(actions[1]).toEqual(expectedResponse);
  });

  it('given feature settings loadFeatureSwitches updates state to show feature', () => {
    const features = { singlePluginLogo: true };

    const action = loadFeatureSwitches(features);
    expect(action.type).toEqual(ConfigureFeatureSwitchesType);
    expect(action.payload.switches).toEqual({ singlePluginLogo: true });
  });

  it('given a feature switch loadFeatureSwitches is run', async () => {
    vi.mocked(mockAxios.get).mockImplementation(() =>
      Promise.resolve({
        data: {
          features: { singlePluginLogo: true },
          'ui-strings': '/res/default.json',
        },
      })
    );

    const asyncAction = configureSite();
    const actions: Action[] = [];
    const dispatch = (action: Action): number => actions.push(action);
    const getState = (): Partial<StateType> => ({
      scigateway: initialState,
    });

    await asyncAction(dispatch, getState);

    expect(actions).toContainEqual(
      loadFeatureSwitches({ singlePluginLogo: true })
    );
  });

  it('given a homepageUrl registration is run', async () => {
    vi.mocked(mockAxios.get).mockImplementation(() =>
      Promise.resolve({
        data: {
          homepageUrl: '/test',
        },
      })
    );

    const asyncAction = configureSite();
    const actions: Action[] = [];
    const dispatch = (action: Action): number => actions.push(action);
    const getState = (): Partial<StateType> => ({
      scigateway: initialState,
    });

    await asyncAction(dispatch, getState);

    expect(actions).toContainEqual(registerHomepageUrl('/test'));
  });

  it('given a custom logo is supplied', async () => {
    vi.mocked(mockAxios.get).mockImplementation(() =>
      Promise.resolve({
        data: {
          logo: '/test',
        },
      })
    );

    const asyncAction = configureSite();
    const actions: Action[] = [];
    const dispatch = (action: Action): number => actions.push(action);
    const getState = (): Partial<StateType> => ({
      scigateway: initialState,
    });

    await asyncAction(dispatch, getState);

    expect(actions).toContainEqual(customLogo('/test'));
  });

  it('given a custom navigation drawer logo is supplied', async () => {
    vi.mocked(mockAxios.get).mockImplementation(() =>
      Promise.resolve({
        data: {
          navigationDrawerLogo: {
            light: '/test',
            dark: '/test',
            altTxt: 'alt-txt',
          },
        },
      })
    );

    const asyncAction = configureSite();
    const actions: Action[] = [];
    const dispatch = (action: Action): number => actions.push(action);
    const getState = (): Partial<StateType> => ({
      scigateway: initialState,
    });

    await asyncAction(dispatch, getState);

    expect(actions).toContainEqual(
      customNavigationDrawerLogo({
        light: '/test',
        dark: '/test',
        altTxt: 'alt-txt',
      })
    );
  });

  it('given a custom default tab is supplied (maintenance)', async () => {
    vi.mocked(mockAxios.get).mockImplementation(() =>
      Promise.resolve({
        data: {
          adminPageDefaultTab: 'maintenance',
        },
      })
    );

    const asyncAction = configureSite();
    const actions: Action[] = [];
    const dispatch = (action: Action): number => actions.push(action);
    const getState = (): Partial<StateType> => ({
      scigateway: initialState,
    });

    await asyncAction(dispatch, getState);

    expect(actions).toContainEqual(customAdminPageDefaultTab('maintenance'));
  });

  it('given a custom default tab is supplied (download)', async () => {
    vi.mocked(mockAxios.get).mockImplementation(() =>
      Promise.resolve({
        data: {
          adminPageDefaultTab: 'download',
        },
      })
    );

    const asyncAction = configureSite();
    const actions: Action[] = [];
    const dispatch = (action: Action): number => actions.push(action);
    const getState = (): Partial<StateType> => ({
      scigateway: initialState,
    });

    await asyncAction(dispatch, getState);

    expect(actions).toContainEqual(customAdminPageDefaultTab('download'));
  });

  it('given a ga-tracking-id configureAnalytics is run', async () => {
    vi.mocked(mockAxios.get).mockImplementation(() =>
      Promise.resolve({
        data: {
          'ga-tracking-id': 'test-tracking-id',
          'ui-strings': '/res/default.json',
        },
      })
    );

    const asyncAction = configureSite();
    const actions: Action[] = [];
    const dispatch = (action: Action): number => actions.push(action);
    const getState = (): Partial<StateType> => ({
      scigateway: initialState,
    });

    await asyncAction(dispatch, getState);

    expect(actions).toContainEqual(configureAnalytics('test-tracking-id'));
  });

  it('given a custom primary colour it is loading from the settings', async () => {
    vi.mocked(mockAxios.get).mockImplementation(() =>
      Promise.resolve({
        data: {
          primaryColour: '#ABCDEF',
          'ui-strings': '/res/default.json',
        },
      })
    );

    const asyncAction = configureSite();
    const actions: Action[] = [];
    const dispatch = (action: Action): number => actions.push(action);
    const getState = (): Partial<StateType> => ({
      scigateway: initialState,
    });

    await asyncAction(dispatch, getState);

    expect(actions).toContainEqual(customPrimaryColour('#ABCDEF'));
  });

  it('dispatches a site loading update after settings are loaded', async () => {
    vi.mocked(mockAxios.get).mockImplementation(() =>
      Promise.resolve({
        data: {
          features: { singlePluginLogo: true },
          plugins: [{ test: 'test' }],
          'ui-strings': '/res/default.json',
        },
      })
    );

    const asyncAction = configureSite();
    const actions: Action[] = [];
    const dispatch = (action: Action): void | Promise<void> => {
      if (typeof action === 'function') {
        action(dispatch);
        return Promise.resolve();
      } else {
        actions.push(action);
      }
    };

    const state = JSON.parse(JSON.stringify(initialState));
    const testAuthProvider = new TestAuthProvider('token');
    testAuthProvider.verifyLogIn = vi
      .fn()
      .mockImplementationOnce(() => Promise.resolve());
    state.authorisation.provider = testAuthProvider;
    const getState = (): Partial<StateType> => ({
      scigateway: state,
    });

    await asyncAction(dispatch, getState);

    expect(loadMicroFrontends.init).toHaveBeenCalledWith([{ test: 'test' }]);
    expect(actions).toContainEqual(authorised());
    expect(actions).toContainEqual(siteLoadingUpdate(false));
  });

  it('dispatches a site loading update after settings are loaded with failed auth, no features, no leading slash on ui-strings and timeout on plugin route', async () => {
    vi.useFakeTimers();

    vi.mocked(mockAxios.get).mockImplementation(() =>
      Promise.resolve({
        data: {
          'ui-strings': 'res/default.json',
        },
      })
    );

    const asyncAction = configureSite();
    const actions: Action[] = [];
    const dispatch = (action: Action): void | Promise<void> => {
      if (typeof action === 'function') {
        action(dispatch);
        return Promise.resolve();
      } else {
        actions.push(action);
      }
    };

    const state = JSON.parse(JSON.stringify(initialState));
    state.authorisation.provider = new TestAuthProvider('token');
    const getState = (): Partial<StateType> => ({
      scigateway: state,
    });

    const configureSiteAction = asyncAction(dispatch, getState);
    // vi fake timers and promises don't play well together so need to flush all promises before running the timer
    await flushPromises();
    vi.runAllTimers();

    await configureSiteAction;
    expect(actions).toContainEqual(invalidToken());

    expect(actions).toContainEqual(siteLoadingUpdate(false));
  });

  it('dispatches a site loading update after plugin route register action detected', async () => {
    const registerRouteAction = {
      type: 'scigateway:api:register_route',
      payload: {
        section: 'Analysis',
        link: '/test',
        plugin: 'demo_plugin',
        displayName: 'Demo Plugin Analysis',
        order: 4,
        broadcast: false,
      },
    };

    document.addEventListener = vi.fn(
      (_id: string, inputHandler: (event: Event) => void) => {
        inputHandler(new CustomEvent('test', { detail: registerRouteAction }));
      }
    );

    vi.mocked(mockAxios.get).mockImplementation(() =>
      Promise.resolve({
        data: {
          'ui-strings': 'res/default.json',
        },
      })
    );

    const asyncAction = configureSite();
    const actions: Action[] = [];
    const dispatch = (action: Action): void | Promise<void> => {
      if (typeof action === 'function') {
        action(dispatch);
        return Promise.resolve();
      } else {
        actions.push(action);
      }
    };

    const state = JSON.parse(JSON.stringify(initialState));
    state.authorisation.provider = new TestAuthProvider('token');
    const getState = (): Partial<StateType> => ({
      scigateway: state,
    });

    await asyncAction(dispatch, getState);

    expect(actions).toContainEqual(siteLoadingUpdate(false));
  });

  it("dispatches a site loading update but doesn't wait for register route event if it's already been recieved", async () => {
    vi.mocked(mockAxios.get).mockImplementation(() =>
      Promise.resolve({
        data: {
          'ui-strings': 'res/default.json',
        },
      })
    );

    const asyncAction = configureSite();
    const actions: Action[] = [];
    const dispatch = (action: Action): void | Promise<void> => {
      if (typeof action === 'function') {
        action(dispatch);
        return Promise.resolve();
      } else {
        actions.push(action);
      }
    };

    const state = JSON.parse(JSON.stringify(initialState));
    state.authorisation.provider = new TestAuthProvider('token');
    state.plugins = [
      {
        section: 'Analysis',
        link: '/test',
        plugin: 'demo_plugin',
        displayName: 'Demo Plugin Analysis',
      },
    ];
    const getState = (): Partial<StateType> => ({
      scigateway: state,
    });

    const eventListenerSpy = vi.spyOn(document, 'addEventListener');

    await asyncAction(dispatch, getState);

    expect(eventListenerSpy).not.toHaveBeenCalled();
    expect(actions).toContainEqual(siteLoadingUpdate(false));
  });

  it("given an authenticator that supports autologin, autologin is attempted when user isn't logged in", async () => {
    vi.mocked(mockAxios.get).mockImplementation(() =>
      Promise.resolve({
        data: {
          'ui-strings': '/res/default.json',
        },
      })
    );

    const asyncAction = configureSite();
    let actions: Action[] = [];
    const dispatch = (action: Action): void | Promise<void> => {
      if (typeof action === 'function') {
        action(dispatch);
        return Promise.resolve();
      } else {
        actions.push(action);
      }
    };
    const state = JSON.parse(JSON.stringify(initialState));
    const testAuthProvider = new TestAuthProvider(null);
    testAuthProvider.autoLogin = () => Promise.resolve();
    state.authorisation.provider = testAuthProvider;
    const getState = (): Partial<StateType> => ({
      scigateway: state,
    });

    await asyncAction(dispatch, getState);

    expect(actions).toContainEqual(loadingAuthentication());
    expect(actions).toContainEqual(authorised());

    actions = [];
    testAuthProvider.autoLogin = () => Promise.reject();
    await asyncAction(dispatch, getState);

    expect(actions).toContainEqual(loadingAuthentication());
    expect(actions).toContainEqual(loadedAuthentication());
  });

  it('given an authenticator that supports autologin, autologin is attempted when user was logged in but verification failed', async () => {
    vi.mocked(mockAxios.get).mockImplementation(() =>
      Promise.resolve({
        data: {
          'ui-strings': '/res/default.json',
        },
      })
    );

    const asyncAction = configureSite();
    let actions: Action[] = [];
    const dispatch = (action: Action): void | Promise<void> => {
      if (typeof action === 'function') {
        action(dispatch);
        return Promise.resolve();
      } else {
        actions.push(action);
      }
    };
    const state = JSON.parse(JSON.stringify(initialState));
    const testAuthProvider = new TestAuthProvider('token');
    testAuthProvider.verifyLogIn = vi
      .fn()
      .mockImplementation(() => Promise.reject());
    testAuthProvider.autoLogin = () => Promise.resolve();
    state.authorisation.provider = testAuthProvider;
    const getState = (): Partial<StateType> => ({
      scigateway: state,
    });

    await asyncAction(dispatch, getState);

    expect(actions).toContainEqual(loadingAuthentication());
    expect(actions).toContainEqual(authorised());

    actions = [];
    testAuthProvider.autoLogin = () => Promise.reject();
    await asyncAction(dispatch, getState);

    expect(actions).toContainEqual(loadingAuthentication());
    expect(actions).toContainEqual(invalidToken());
  });

  it('given an index number dismissMenuItem returns a DismissNotificationType with payload', () => {
    const action = dismissMenuItem(0);
    expect(action.type).toEqual(DismissNotificationType);
    expect(action.payload).toEqual({ index: 0 });
  });

  it('given an id configureAnalytics returns a ConfigureAnalytics type with payload', () => {
    const action = configureAnalytics('test id');
    expect(action.type).toEqual(ConfigureAnalyticsType);
    expect(action.payload).toEqual({ id: 'test id' });
  });

  it('initialiseAnalytics returns an InitialiseAnalyticsType', () => {
    const action = initialiseAnalytics();
    expect(action.type).toEqual(InitialiseAnalyticsType);
  });

  it('toggleHelp only needs a type', () => {
    const action = toggleHelp();
    expect(action.type).toEqual(ToggleHelpType);
  });

  it('resetAuthState only needs a type', () => {
    const action = resetAuthState();
    expect(action.type).toEqual(ResetAuthStateType);
  });

  it('given a steps array addHelpTourSteps returns a AddHelpTourStepsType with payload', () => {
    const action = addHelpTourSteps([{ target: '.test', content: 'test' }]);
    expect(action.type).toEqual(AddHelpTourStepsType);
    expect(action.payload.steps.length).toEqual(1);
    expect(action.payload.steps[0]).toEqual({
      target: '.test',
      content: 'test',
    });
  });

  it('should load dark mode preference into store', async () => {
    vi.mocked(mockAxios.get).mockImplementation(() =>
      Promise.resolve({
        data: {
          'ui-strings': 'res/default.json',
        },
      })
    );

    vi.spyOn(window.localStorage.__proto__, 'getItem');
    window.localStorage.__proto__.getItem = vi
      .fn()
      .mockImplementation((name) => (name === 'darkMode' ? 'true' : 'false'));

    const asyncAction = configureSite();
    const actions: Action[] = [];
    const dispatch = (action: Action): number => actions.push(action);
    const getState = (): Partial<StateType> => ({
      scigateway: initialState,
    });

    await asyncAction(dispatch, getState);

    expect(localStorage.getItem).toBeCalledWith('darkMode');
    expect(actions).toContainEqual(loadDarkModePreference(true));
  });

  it('should load high contrast mode preference into store', async () => {
    vi.mocked(mockAxios.get).mockImplementation(() =>
      Promise.resolve({
        data: {
          'ui-strings': 'res/default.json',
        },
      })
    );

    vi.spyOn(window.localStorage.__proto__, 'getItem');
    window.localStorage.__proto__.getItem = vi
      .fn()
      .mockImplementation((name) =>
        name === 'highContrastMode' ? 'true' : 'false'
      );

    const asyncAction = configureSite();
    const actions: Action[] = [];
    const dispatch = (action: Action): number => actions.push(action);
    const getState = (): Partial<StateType> => ({
      scigateway: initialState,
    });

    await asyncAction(dispatch, getState);

    expect(localStorage.getItem).toBeCalledWith('highContrastMode');
    expect(actions).toContainEqual(loadHighContrastModePreference(true));
  });

  it('logs an error if settings.json fails to be loaded', async () => {
    vi.mocked(mockAxios.get).mockImplementationOnce(() => Promise.reject({}));
    log.error = vi.fn();

    const asyncAction = configureSite();
    const actions: Action[] = [];
    const dispatch = (action: Action): number => actions.push(action);
    const getState = (): Partial<StateType> => ({ scigateway: initialState });
    await asyncAction(dispatch, getState);

    expect(log.error).toHaveBeenCalled();
    const mockLog = vi.mocked(log.error).mock;
    expect(mockLog.calls[0][0]).toEqual(
      expect.stringContaining('Error loading settings.json: ')
    );
  });

  it('logs an error if settings.json is invalid JSON object', async () => {
    vi.mocked(mockAxios.get).mockImplementationOnce(() =>
      Promise.resolve({
        data: 1,
      })
    );
    log.error = vi.fn();

    const asyncAction = configureSite();
    const actions: Action[] = [];
    const dispatch = (action: Action): number => actions.push(action);
    const getState = (): Partial<StateType> => ({ scigateway: initialState });
    await asyncAction(dispatch, getState);

    expect(log.error).toHaveBeenCalled();
    const mockLog = vi.mocked(log.error).mock;
    expect(mockLog.calls[0][0]).toEqual(
      'Error loading settings.json: Invalid format'
    );
  });

  it('logs an error if loadStrings fails to resolve', async () => {
    vi.mocked(mockAxios.get).mockImplementationOnce(() => Promise.reject({}));
    log.error = vi.fn();

    const path = 'non/existent/path';
    const asyncAction = loadStrings(path);
    const actions: Action[] = [];
    const dispatch = (action: Action): number => actions.push(action);
    const getState = (): Partial<StateType> => ({ scigateway: initialState });

    await asyncAction(dispatch, getState);

    expect(log.error).toHaveBeenCalled();
    const mockLog = vi.mocked(log.error).mock;
    expect(mockLog.calls[0][0]).toEqual(
      expect.stringContaining(`Failed to read strings from ${path}: `)
    );
  });

  it('should load scheduled maintenance state into store', async () => {
    vi.mocked(mockAxios.get).mockImplementation(() =>
      Promise.resolve({
        data: {},
      })
    );

    const asyncAction = configureSite();
    const actions: Action[] = [];
    const dispatch = (action: Action): number => actions.push(action);
    const state = JSON.parse(JSON.stringify(initialState));
    state.authorisation.provider = new TestAuthProvider(null);

    const getState = (): Partial<StateType> => ({ scigateway: state });

    await asyncAction(dispatch, getState);

    expect(actions).toContainEqual(
      loadScheduledMaintenanceState({
        show: false,
        message: 'test',
        severity: 'warning',
      })
    );
  });

  it('should not display a warning when maintenance is not scheduled or enabled', async () => {
    vi.mocked(mockAxios.get).mockImplementation(() =>
      Promise.resolve({
        data: {},
      })
    );

    const events: CustomEvent<AnyAction>[] = [];
    const dispatchEventSpy = vi
      .spyOn(document, 'dispatchEvent')
      .mockImplementation((e) => {
        events.push(e as CustomEvent<AnyAction>);
        return true;
      });
    const asyncAction = configureSite();
    const actions: Action[] = [];
    const dispatch = (action: Action): number => actions.push(action);
    const state = JSON.parse(JSON.stringify(initialState));
    state.authorisation.provider = new TestAuthProvider(null);

    const getState = (): Partial<StateType> => ({ scigateway: state });

    await asyncAction(dispatch, getState);

    expect(dispatchEventSpy).not.toHaveBeenCalled();
    expect(events.length).toEqual(0);
  });

  it('should display a warning when maintenance is scheduled', async () => {
    vi.mocked(mockAxios.get).mockImplementation(() =>
      Promise.resolve({
        data: {},
      })
    );

    const events: CustomEvent<AnyAction>[] = [];
    const dispatchEventSpy = vi
      .spyOn(document, 'dispatchEvent')
      .mockImplementation((e) => {
        events.push(e as CustomEvent<AnyAction>);
        return true;
      });
    const asyncAction = configureSite();
    const actions: Action[] = [];
    const dispatch = (action: Action): number => actions.push(action);
    const state = JSON.parse(JSON.stringify(initialState));
    const testAuthProvider = new TestAuthProvider(null);
    testAuthProvider.fetchScheduledMaintenanceState = () =>
      Promise.resolve({
        show: true,
        message: 'test',
        severity: 'warning',
      });
    state.authorisation.provider = testAuthProvider;

    const getState = (): Partial<StateType> => ({ scigateway: state });

    await asyncAction(dispatch, getState);

    expect(dispatchEventSpy).toHaveBeenCalled();
    expect(events.length).toEqual(1);
    expect(events[0].detail).toEqual({
      type: NotificationType,
      payload: {
        message: 'test',
        severity: 'warning',
        instant: false,
      },
    });
  });

  it('should load maintenance state into store', async () => {
    vi.mocked(mockAxios.get).mockImplementation(() =>
      Promise.resolve({
        data: {},
      })
    );

    const asyncAction = configureSite();
    const actions: Action[] = [];
    const dispatch = (action: Action): number => actions.push(action);
    const state = JSON.parse(JSON.stringify(initialState));
    state.authorisation.provider = new TestAuthProvider(null);

    const getState = (): Partial<StateType> => ({ scigateway: state });

    await asyncAction(dispatch, getState);

    expect(actions).toContainEqual(
      loadMaintenanceState({ show: false, message: 'test' })
    );
  });

  it('should display a warning when in maintenance', async () => {
    vi.mocked(mockAxios.get).mockImplementation(() =>
      Promise.resolve({
        data: {},
      })
    );

    const events: CustomEvent<AnyAction>[] = [];
    const dispatchEventSpy = vi
      .spyOn(document, 'dispatchEvent')
      .mockImplementation((e) => {
        events.push(e as CustomEvent<AnyAction>);
        return true;
      });
    const asyncAction = configureSite();
    const actions: Action[] = [];
    const dispatch = (action: Action): number => actions.push(action);
    const state = JSON.parse(JSON.stringify(initialState));
    const testAuthProvider = new TestAuthProvider(null);
    testAuthProvider.fetchMaintenanceState = () =>
      Promise.resolve({
        show: true,
        message: 'test',
      });
    state.authorisation.provider = testAuthProvider;

    const getState = (): Partial<StateType> => ({ scigateway: state });

    await asyncAction(dispatch, getState);

    expect(dispatchEventSpy).toHaveBeenCalled();
    expect(events.length).toEqual(1);
    expect(events[0].detail).toEqual({
      type: NotificationType,
      payload: {
        message: 'test',
        severity: 'warning',
        instant: false,
      },
    });
  });

  it('given a contactUsAccessibilityFormUrl, registration is run', async () => {
    vi.mocked(mockAxios.get).mockImplementation(() =>
      Promise.resolve({
        data: {
          contactUsAccessibilityFormUrl: '/test',
        },
      })
    );

    const asyncAction = configureSite();
    const actions: Action[] = [];
    const dispatch = (action: Action): number => actions.push(action);
    const getState = (): Partial<StateType> => ({
      scigateway: initialState,
    });

    await asyncAction(dispatch, getState);

    expect(actions).toContainEqual(
      registerContactUsAccessibilityFormUrl('/test')
    );
  });
});
