import log from 'loglevel';
import { Step } from 'react-joyride';
import GithubAuthProvider from '../../authentication/githubAuthProvider';
import ICATAuthProvider from '../../authentication/icatAuthProvider';
import JWTAuthProvider from '../../authentication/jwtAuthProvider';
import LoadingAuthProvider from '../../authentication/loadingAuthProvider';
import NullAuthProvider from '../../authentication/nullAuthProvider';
import OIDCAuthProvider from '../../authentication/oidcAuthProvider';
import PasswordAndOIDCAuthProvider from '../../authentication/passwordAndOIDCAuthProvider';
import { singleSpaPluginRoutes } from '../actions/loadMicroFrontends';
import { buildPluginConfig } from '../pluginhelper';
import {
  AddHelpTourStepsPayload,
  AddHelpTourStepsType,
  AuthFailurePayload,
  AuthFailureType,
  AuthProviderPayload,
  AuthSuccessType,
  AutoLoginSuccessType,
  ConfigureAnalyticsPayload,
  ConfigureAnalyticsType,
  ConfigureFeatureSwitchesType,
  ConfigureStringsPayload,
  ConfigureStringsType,
  ContactUsAccessibilityFormUrlPayload,
  CustomAdminPageDefaultTabPayload,
  CustomAdminPageDefaultTabType,
  CustomLogoPayload,
  CustomLogoType,
  CustomNavigationDrawerLogoPayload,
  CustomNavigationDrawerLogoType,
  CustomPrimaryColourPayload,
  CustomPrimaryColourType,
  DismissNotificationType,
  FeatureSwitchesPayload,
  HomepageUrlPayload,
  InitialiseAnalyticsType,
  InvalidateTokenType,
  LoadAuthProviderType,
  LoadDarkModePreferencePayload,
  LoadDarkModePreferenceType,
  LoadedAuthType,
  LoadHighContrastModePreferencePayload,
  LoadHighContrastModePreferenceType,
  LoadingAuthType,
  LoadMaintenanceStateType,
  LoadScheduledMaintenanceStateType,
  MaintenanceStatePayLoad,
  NotificationPayload,
  NotificationType,
  PluginConfig,
  RegisterContactUsAccessibilityFormUrlType,
  RegisterHomepageUrlType,
  RegisterRoutePayload,
  RegisterRouteType,
  ResetAuthStateType,
  ScheduledMaintenanceStatePayLoad,
  SignOutType,
  SiteLoadingPayload,
  SiteLoadingType,
  ToggleDrawerType,
  ToggleHelpType,
} from '../scigateway.types';
import { AuthState, ScigatewayState } from '../state.types';
import createReducer from './createReducer';

export const authState: AuthState = {
  failedToLogin: false,
  signedOutDueToTokenInvalidation: false,
  loading: false,
  provider: new LoadingAuthProvider(),
};

export const initialState: ScigatewayState = {
  notifications: [],
  plugins: [],
  drawerOpen: false,
  siteLoading: true,
  showHelp: false,
  helpSteps: [],
  authorisation: authState,
  features: {
    showHelpPageButton: true,
    singlePluginLogo: false,
  },
  darkMode: false,
  highContrastMode: false,
  scheduledMaintenance: {
    show: false,
    message: '',
    severity: 'warning',
  },
  maintenance: {
    show: false,
    message: '',
  },
};

export function handleNotification(
  state: ScigatewayState,
  payload: NotificationPayload
): ScigatewayState {
  // Do not add the notification to state if a notification
  // with the same message already exists.
  if (state.notifications.some((n) => n.message === payload.message)) {
    return state;
  }

  return {
    ...state,
    notifications: [
      ...state.notifications,
      { message: payload.message, severity: payload.severity },
    ],
  };
}

export function handleDrawerToggle(state: ScigatewayState): ScigatewayState {
  return {
    ...state,
    drawerOpen: !state.drawerOpen,
  };
}

export function handleConfigureStrings(
  state: ScigatewayState,
  payload: ConfigureStringsPayload
): ScigatewayState {
  return {
    ...state,
    res: payload.res,
  };
}

const updatePlugins = (
  existingPlugins: PluginConfig[],
  payload: RegisterRoutePayload
): PluginConfig[] => {
  const basePluginLink = payload.link.split('?')[0];
  if (singleSpaPluginRoutes[payload.plugin]) {
    if (!singleSpaPluginRoutes[payload.plugin].includes(basePluginLink))
      singleSpaPluginRoutes[payload.plugin].push(basePluginLink);
  } else {
    singleSpaPluginRoutes[payload.plugin] = [basePluginLink];
  }

  if (!existingPlugins.some((p) => p.link === basePluginLink)) {
    return [...existingPlugins, buildPluginConfig(payload)];
  }

  log.error(
    `Duplicate plugin route identified: ${basePluginLink}.
     ${payload.plugin}:'${payload.displayName}' not registered`
  );
  return existingPlugins;
};

export function handleRegisterPlugin(
  state: ScigatewayState,
  payload: RegisterRoutePayload
): ScigatewayState {
  return {
    ...state,
    plugins: updatePlugins(state.plugins, payload),
  };
}

export const handleLoadingAuth = (state: ScigatewayState): ScigatewayState => ({
  ...state,
  authorisation: {
    ...state.authorisation,
    loading: true,
  },
});

export const handleLoadedAuth = (state: ScigatewayState): ScigatewayState => ({
  ...state,
  authorisation: {
    ...state.authorisation,
    loading: false,
  },
});

export function handleSuccessfulLogin(state: ScigatewayState): ScigatewayState {
  log.debug(`Successfully logged in`);
  return {
    ...state,
    authorisation: {
      ...state.authorisation,
      failedToLogin: false,
      signedOutDueToTokenInvalidation: false,
      loading: false,
    },
  };
}

export function handleSuccessfulAutoLogin(
  state: ScigatewayState
): ScigatewayState {
  log.debug(`Successfully auto logged in`);
  return {
    ...state,
    authorisation: {
      ...state.authorisation,
      loading: false,
    },
  };
}

const resetAuth = (authorisation: AuthState): AuthState => {
  return {
    ...authorisation,
    failedToLogin: false,
    signedOutDueToTokenInvalidation: false,
    loading: false,
  };
};

export function handleUnsuccessfulLogin(
  state: ScigatewayState,
  payload: AuthFailurePayload
): ScigatewayState {
  log.debug(`Failed to log in with error ${payload.errorCode}`);
  state.authorisation.provider.logOut();
  return {
    ...state,
    authorisation: {
      ...resetAuth(state.authorisation),
      failedToLogin: true,
      errorCode: payload.errorCode,
    },
  };
}

export function handleSignOut(state: ScigatewayState): ScigatewayState {
  log.debug(`User is being signed out`);
  state.authorisation.provider.logOut();
  return {
    ...state,
    authorisation: resetAuth(state.authorisation),
  };
}

export function handleResetAuthState(state: ScigatewayState): ScigatewayState {
  return {
    ...state,
    authorisation: {
      ...resetAuth(state.authorisation),
    },
  };
}

export function handleTokenExpiration(state: ScigatewayState): ScigatewayState {
  state.authorisation.provider.logOut();
  return {
    ...state,
    authorisation: {
      ...resetAuth(state.authorisation),
      signedOutDueToTokenInvalidation: true,
    },
  };
}

export function handleConfigureFeatureSwitches(
  state: ScigatewayState,
  payload: FeatureSwitchesPayload
): ScigatewayState {
  return {
    ...state,
    features: payload.switches,
  };
}

export function handleLoadScheduledMaintenanceState(
  state: ScigatewayState,
  payload: ScheduledMaintenanceStatePayLoad
): ScigatewayState {
  return {
    ...state,
    scheduledMaintenance: payload.scheduledMaintenance,
  };
}

export function handleLoadMaintenanceState(
  state: ScigatewayState,
  payload: MaintenanceStatePayLoad
): ScigatewayState {
  return {
    ...state,
    maintenance: payload.maintenance,
  };
}

export function handleRegisterHomepageUrl(
  state: ScigatewayState,
  payload: HomepageUrlPayload
): ScigatewayState {
  return {
    ...state,
    homepageUrl: payload.homepageUrl,
  };
}

export function handleCustomLogo(
  state: ScigatewayState,
  payload: CustomLogoPayload
): ScigatewayState {
  return {
    ...state,
    logo: payload.logo,
  };
}

export function handleCustomNavigationDrawerLogo(
  state: ScigatewayState,
  payload: CustomNavigationDrawerLogoPayload
): ScigatewayState {
  return {
    ...state,
    navigationDrawerLogo: payload.navigationDrawerLogo,
  };
}

export function handleCustomAdminPageDefaultTab(
  state: ScigatewayState,
  payload: CustomAdminPageDefaultTabPayload
): ScigatewayState {
  return {
    ...state,
    adminPageDefaultTab: payload.adminPageDefaultTab,
  };
}

export function handleCustomPrimaryColour(
  state: ScigatewayState,
  payload: CustomPrimaryColourPayload
): ScigatewayState {
  return {
    ...state,
    primaryColour: payload.primaryColour,
  };
}

export function handleDismissNotification(
  state: ScigatewayState,
  payload: { index: number }
): ScigatewayState {
  return {
    ...state,
    notifications: [
      ...state.notifications.filter(
        (_notification, index) => index !== payload.index
      ),
    ],
  };
}

export function handleAuthProviderUpdate(
  state: ScigatewayState,
  payload: AuthProviderPayload
): ScigatewayState {
  let provider = state.authorisation.provider;

  if (payload.authProvider === null) {
    provider = new NullAuthProvider();
  } else {
    switch (payload.authProvider.split('.')[0]) {
      case 'jwt':
        provider = new JWTAuthProvider(payload.authUrl);
        break;

      case 'oidc':
        provider = new OIDCAuthProvider(payload.authUrl);
        break;

      case 'userpass_and_oidc':
        provider = new PasswordAndOIDCAuthProvider(payload.authUrl);
        break;

      case 'github':
        provider = new GithubAuthProvider(payload.authUrl);
        break;

      case 'icat':
        provider = new ICATAuthProvider(
          payload.authProvider.replace('icat.', ''),
          payload.authUrl,
          payload.autoLogin
        );
        break;

      default:
        throw Error(
          `Unrecognised auth provider: ${payload.authProvider}, this is a development issue as there is no implementation registered for this provider.`
        );
    }
  }

  return {
    ...state,
    authorisation: {
      ...resetAuth(state.authorisation),
      provider,
    },
  };
}

export function handleSiteLoadingUpdate(
  state: ScigatewayState,
  payload: SiteLoadingPayload
): ScigatewayState {
  return {
    ...state,
    siteLoading: payload.loading,
  };
}

export function handleConfigureAnalytics(
  state: ScigatewayState,
  payload: ConfigureAnalyticsPayload
): ScigatewayState {
  return {
    ...state,
    analytics: {
      id: payload.id,
      initialised: false,
    },
  };
}

export function handleInitialiseAnalytics(
  state: ScigatewayState
): ScigatewayState {
  if (state.analytics) {
    return {
      ...state,
      analytics: {
        id: state.analytics.id,
        initialised: true,
      },
    };
  } else {
    log.error(
      `Attempted to initialise analytics without analytics configuration -
      configureAnalytics needs to be performed before initialising`
    );
    return state;
  }
}

export function handleToggleHelp(state: ScigatewayState): ScigatewayState {
  return {
    ...state,
    showHelp: !state.showHelp,
  };
}

const updateHelpSteps = (
  existingHelpSteps: Step[],
  newSteps: Step[]
): Step[] => {
  const newHelpSteps = [...existingHelpSteps];

  newSteps.forEach((newStep) => {
    if (
      !existingHelpSteps.some(
        (existingStep) => existingStep.target === newStep.target
      )
    ) {
      newHelpSteps.push(newStep);
    } else {
      log.error(`Duplicate help step target identified: ${newStep.target}.`);
    }
  });
  return newHelpSteps;
};

export function handleAddHelpTourSteps(
  state: ScigatewayState,
  payload: AddHelpTourStepsPayload
): ScigatewayState {
  return {
    ...state,
    helpSteps: updateHelpSteps(state.helpSteps, payload.steps),
    // helpSteps: [...state.helpSteps, ...payload.steps],
  };
}

export function handleLoadDarkModePreference(
  state: ScigatewayState,
  payload: LoadDarkModePreferencePayload
): ScigatewayState {
  return {
    ...state,
    darkMode: payload.darkMode,
  };
}

export function handleLoadHighContrastModePreference(
  state: ScigatewayState,
  payload: LoadHighContrastModePreferencePayload
): ScigatewayState {
  return {
    ...state,
    highContrastMode: payload.highContrastMode,
  };
}

export function handleRegisterContactUsAccessibilityFormUrl(
  state: ScigatewayState,
  payload: ContactUsAccessibilityFormUrlPayload
): ScigatewayState {
  return {
    ...state,
    contactUsAccessibilityFormUrl: payload.contactUsAccessibilityFormUrl,
  };
}

const ScigatewayReducer = createReducer(initialState, {
  [NotificationType]: handleNotification,
  [ToggleDrawerType]: handleDrawerToggle,
  [RegisterRouteType]: handleRegisterPlugin,
  [AuthSuccessType]: handleSuccessfulLogin,
  [AuthFailureType]: handleUnsuccessfulLogin,
  [AutoLoginSuccessType]: handleSuccessfulAutoLogin,
  [LoadingAuthType]: handleLoadingAuth,
  [LoadedAuthType]: handleLoadedAuth,
  [LoadAuthProviderType]: handleAuthProviderUpdate,
  [ConfigureStringsType]: handleConfigureStrings,
  [SignOutType]: handleSignOut,
  [ResetAuthStateType]: handleResetAuthState,
  [InvalidateTokenType]: handleTokenExpiration,
  [ConfigureFeatureSwitchesType]: handleConfigureFeatureSwitches,
  [LoadScheduledMaintenanceStateType]: handleLoadScheduledMaintenanceState,
  [LoadMaintenanceStateType]: handleLoadMaintenanceState,
  [DismissNotificationType]: handleDismissNotification,
  [SiteLoadingType]: handleSiteLoadingUpdate,
  [ConfigureAnalyticsType]: handleConfigureAnalytics,
  [InitialiseAnalyticsType]: handleInitialiseAnalytics,
  [ToggleHelpType]: handleToggleHelp,
  [AddHelpTourStepsType]: handleAddHelpTourSteps,
  [LoadDarkModePreferenceType]: handleLoadDarkModePreference,
  [LoadHighContrastModePreferenceType]: handleLoadHighContrastModePreference,
  [RegisterHomepageUrlType]: handleRegisterHomepageUrl,
  [CustomLogoType]: handleCustomLogo,
  [CustomNavigationDrawerLogoType]: handleCustomNavigationDrawerLogo,
  [CustomAdminPageDefaultTabType]: handleCustomAdminPageDefaultTab,
  [RegisterContactUsAccessibilityFormUrlType]:
    handleRegisterContactUsAccessibilityFormUrl,
  [CustomPrimaryColourType]: handleCustomPrimaryColour,
});

export default ScigatewayReducer;
