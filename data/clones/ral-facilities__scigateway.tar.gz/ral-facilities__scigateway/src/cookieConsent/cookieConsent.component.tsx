import Button from '@mui/material/Button';
import Snackbar from '@mui/material/Snackbar';
import { styled } from '@mui/material/styles';
import Cookies from 'js-cookie';
import React from 'react';
import { connect } from 'react-redux';
import { useLocation, useNavigate } from 'react-router';
import { Action, Dispatch } from 'redux';
import { initialiseAnalytics } from '../state/actions/scigateway.actions';
import { AppStrings, scigatewayRoutes } from '../state/scigateway.types';
import { AnalyticsState, StateType } from '../state/state.types';
import { getAppStrings, getString } from '../state/strings';

const ManageButton = styled(Button)(({ theme }) => ({
  color: '#FFFFFF',
  margin: theme.spacing(1),
}));

const AcceptButton = styled(Button)(({ theme }) => ({
  color: theme.palette.primary.contrastText,
  margin: theme.spacing(1),
}));

interface CookieConsentStateProps {
  analytics?: AnalyticsState;
  res: AppStrings | undefined;
  loading: boolean;
}

interface CookieConsentDispatchProps {
  initialiseAnalytics: () => Action;
}

export type CombinedCookieConsentProps = CookieConsentStateProps &
  CookieConsentDispatchProps;

export const CookieConsent = (
  props: CombinedCookieConsentProps
): React.ReactElement => {
  const [open, setOpen] = React.useState(false);

  const location = useLocation();
  const navigate = useNavigate();

  React.useEffect(() => {
    const consentCookie = JSON.parse(Cookies.get('cookie-consent') ?? 'null');
    if (
      props.analytics &&
      !props.analytics.initialised &&
      consentCookie &&
      consentCookie.analytics
    ) {
      //Global Site Tag (gtag.js) - Google Analytics
      const urlScript = document.createElement('script');
      urlScript.async = true;
      urlScript.src = `https://www.googletagmanager.com/gtag/js?id=${props.analytics.id}`;

      const gtagScript = document.createElement('script');
      gtagScript.innerText =
        'window.dataLayer = window.dataLayer || [];' +
        'function gtag(){dataLayer.push(arguments);}' +
        "gtag('js', new Date());" +
        `gtag('config', '${props.analytics.id}');`;

      document.head.appendChild(urlScript);
      document.head.appendChild(gtagScript);

      props.initialiseAnalytics();
    }

    if (
      props.loading ||
      JSON.parse(Cookies.get('cookie-consent') ?? 'null') ||
      location.pathname === scigatewayRoutes.cookies
    ) {
      setOpen(false);
    } else {
      setOpen(true);
    }
  }, [location.pathname, props]);

  const handleAccept = (
    _event: React.SyntheticEvent | React.MouseEvent
  ): void => {
    Cookies.set('cookie-consent', JSON.stringify({ analytics: true }), {
      expires: 365,
      sameSite: 'None',
      secure: true,
    });
    setOpen(false);
  };

  return (
    <Snackbar
      anchorOrigin={{
        vertical: 'bottom',
        horizontal: 'left',
      }}
      ContentProps={{
        sx: {
          color: 'primary.contrastText',
          backgroundColor: (theme) => theme.colours.darkGreen,
        },
      }}
      open={open}
      message={<div>{getString(props.res, 'text')}</div>}
      action={[
        <ManageButton
          key="decline"
          variant="outlined"
          size="small"
          onClick={() => navigate(scigatewayRoutes.cookies)}
        >
          {getString(props.res, 'manage-preferences-button')}
        </ManageButton>,
        <AcceptButton
          key="accept"
          variant="contained"
          color="primary"
          size="small"
          onClick={handleAccept}
        >
          {getString(props.res, 'accept-button')}
        </AcceptButton>,
      ]}
    />
  );
};

const mapStateToProps = (state: StateType): CookieConsentStateProps => ({
  analytics: state.scigateway.analytics,
  res: getAppStrings(state, 'cookie-consent'),
  loading: state.scigateway.siteLoading,
});

const mapDispatchToProps = (
  dispatch: Dispatch
): CookieConsentDispatchProps => ({
  initialiseAnalytics: () => dispatch(initialiseAnalytics()),
});

export const UnconnectedCookieConsent = CookieConsent;

export default connect(mapStateToProps, mapDispatchToProps)(CookieConsent);
