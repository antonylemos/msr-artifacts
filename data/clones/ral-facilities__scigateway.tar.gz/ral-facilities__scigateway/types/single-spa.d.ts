declare module 'single-spa'
