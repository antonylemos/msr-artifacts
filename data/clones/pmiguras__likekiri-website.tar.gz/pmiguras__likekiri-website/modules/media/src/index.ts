export { MediaPage } from './MediaPage';
