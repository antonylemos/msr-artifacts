export { SimuladorIsland } from './SimuladorIsland';
