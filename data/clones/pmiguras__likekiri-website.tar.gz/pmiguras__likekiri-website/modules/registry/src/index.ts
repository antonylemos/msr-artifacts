export { RegistryPage } from './RegistryPage';
