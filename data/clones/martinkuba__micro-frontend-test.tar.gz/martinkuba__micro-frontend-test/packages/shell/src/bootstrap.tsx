import React from 'react';
import { createRoot } from 'react-dom/client';
import { initFaro } from './faro';
import App from './App';

// Initialize Faro before rendering the app
initFaro();

const container = document.getElementById('root');
if (!container) {
  throw new Error('Root element not found');
}

const root = createRoot(container);
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

