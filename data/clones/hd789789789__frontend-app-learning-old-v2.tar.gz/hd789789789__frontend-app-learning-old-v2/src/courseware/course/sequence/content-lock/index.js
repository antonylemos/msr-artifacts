export { default } from './ContentLock';
