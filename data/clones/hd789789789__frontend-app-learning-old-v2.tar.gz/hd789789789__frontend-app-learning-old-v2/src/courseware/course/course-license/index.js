export { default } from './CourseLicense';
