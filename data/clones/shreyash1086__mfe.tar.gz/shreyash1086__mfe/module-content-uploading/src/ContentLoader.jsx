const ContentLoader = ({ scale = 0.5 }) => {
    return (
        <div className="flex flex-col items-center justify-center w-full h-full" style={{ transform: `scale(${scale})` }}>
            <style>
                {`
                .loader {
                    --background: linear-gradient(135deg, #23C4F8, #275EFE);
                    --shadow: rgba(39, 94, 254, 0.15);
                    --text: #6C7486;
                    --page: rgba(255, 255, 255, 0.36);
                    --page-fold: rgba(255, 255, 255, 0.52);
                    --duration: 3s;
                    width: 200px;
                    height: 140px;
                    position: relative;
                }

                .dark .loader {
                    --text: #9ca3af;
                }

                .loader:before, .loader:after {
                    --r: -6deg;
                    content: "";
                    position: absolute;
                    bottom: 8px;
                    width: 120px;
                    top: 80%;
                    box-shadow: 0 16px 12px var(--shadow);
                    transform: rotate(var(--r));
                }

                .loader:before {
                    left: 4px;
                }

                .loader:after {
                    --r: 6deg;
                    right: 4px;
                }

                .loader div {
                    width: 100%;
                    height: 100%;
                    border-radius: 13px;
                    position: relative;
                    z-index: 1;
                    perspective: 600px;
                    box-shadow: 0 4px 6px var(--shadow);
                    background-image: var(--background);
                    opacity: 0.7;
                }

                .loader div ul {
                    margin: 0;
                    padding: 0;
                    list-style: none;
                    position: relative;
                }

                .loader div ul li {
                    --r: 180deg;
                    --o: 0;
                    --c: var(--page);
                    position: absolute;
                    top: 10px;
                    left: 10px;
                    transform-origin: 100% 50%;
                    color: var(--c);
                    opacity: var(--o);
                    transform: rotateY(var(--r));
                    -webkit-animation: var(--duration) ease infinite;
                    animation: var(--duration) ease infinite;
                }

                .loader div ul li:nth-child(2) {
                    --c: var(--page-fold);
                    -webkit-animation-name: page-2;
                    animation-name: page-2;
                }

                .loader div ul li:nth-child(3) {
                    --c: var(--page-fold);
                    -webkit-animation-name: page-3;
                    animation-name: page-3;
                }

                .loader div ul li:nth-child(4) {
                    --c: var(--page-fold);
                    -webkit-animation-name: page-4;
                    animation-name: page-4;
                }

                .loader div ul li:nth-child(5) {
                    --c: var(--page-fold);
                    -webkit-animation-name: page-5;
                    animation-name: page-5;
                }

                .loader div ul li svg {
                    width: 90px;
                    height: 120px;
                    display: block;
                }

                .loader div ul li:first-child {
                    --r: 0deg;
                    --o: 1;
                }

                .loader div ul li:last-child {
                    --o: 1;
                }

                .loader span {
                    position: absolute;
                    left: 50%;
                    transform: translateX(-50%);
                    width: max-content;
                    top: 100%;
                    color: var(--text);
                }

                @keyframes page-2 {
                    0% {
                        transform: rotateY(180deg);
                        opacity: 0;
                    }

                    20% {
                        opacity: 1;
                    }

                    35%, 100% {
                        opacity: 0;
                    }

                    50%, 100% {
                        transform: rotateY(0deg);
                    }
                }

                @keyframes page-3 {
                    15% {
                        transform: rotateY(180deg);
                        opacity: 0;
                    }

                    35% {
                        opacity: 1;
                    }

                    50%, 100% {
                        opacity: 0;
                    }

                    65%, 100% {
                        transform: rotateY(0deg);
                    }
                }

                @keyframes page-4 {
                    30% {
                        transform: rotateY(180deg);
                        opacity: 0;
                    }

                    50% {
                        opacity: 1;
                    }

                    65%, 100% {
                        opacity: 0;
                    }

                    80%, 100% {
                        transform: rotateY(0deg);
                    }
                }

                @keyframes page-5 {
                    45% {
                        transform: rotateY(180deg);
                        opacity: 0;
                    }

                    65% {
                        opacity: 1;
                    }

                    80%, 100% {
                        opacity: 0;
                    }

                    95%, 100% {
                        transform: rotateY(0deg);
                    }
                }
                `}
            </style>
            <div className="loader">
                <div>
                    <ul>
                        {[...Array(5)].map((_, i) => (
                            <li key={i}>
                                <svg fill="currentColor" viewBox="0 0 90 120">
                                    <path d="M90,0 L90,120 L11,120 C4.92486775,120 0,115.075132 0,109 L0,11 C0,4.92486775 4.92486775,0 11,0 L90,0 Z M71.5,81 L18.5,81 C17.1192881,81 16,82.1192881 16,83.5 C16,84.8254834 17.0315359,85.9100387 18.3356243,85.9946823 L18.5,86 L71.5,86 C72.8807119,86 74,84.8807119 74,83.5 C74,82.1745166 72.9684641,81.0899613 71.6643757,81.0053177 L71.5,81 Z M71.5,57 L18.5,57 C17.1192881,57 16,58.1192881 16,59.5 C16,60.8254834 17.0315359,61.9100387 18.3356243,61.9946823 L18.5,62 L71.5,62 C72.8807119,62 74,60.8807119 74,59.5 C74,58.1192881 72.8807119,57 71.5,57 Z M71.5,33 L18.5,33 C17.1192881,33 16,34.1192881 16,35.5 C16,36.8254834 17.0315359,37.9100387 18.3356243,37.9946823 L18.5,38 L71.5,38 C72.8807119,38 74,36.8807119 74,35.5 C74,34.1192881 72.8807119,33 71.5,33 Z"></path>
                                </svg>
                            </li>
                        ))}
                    </ul>
                </div>
                <span className="font-semibold tracking-wider text-3xl mt-10 whitespace-nowrap">Loading Resources...</span>
            </div>
        </div>
    );
};

export default ContentLoader;
