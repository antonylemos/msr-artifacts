// Shared utilities
export const classNames = (...classes: string[]) => classes.filter(Boolean).join(' ');
