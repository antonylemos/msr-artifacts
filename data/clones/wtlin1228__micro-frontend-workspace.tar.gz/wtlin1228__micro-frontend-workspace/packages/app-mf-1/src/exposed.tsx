export { getRootComponent } from './App';
